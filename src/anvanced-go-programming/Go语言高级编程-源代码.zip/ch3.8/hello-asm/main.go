package main

func main() { asmSayHello() }

func asmSayHello()
