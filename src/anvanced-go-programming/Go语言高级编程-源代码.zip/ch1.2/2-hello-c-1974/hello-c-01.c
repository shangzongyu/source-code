main()
{
	printf("hello, world");
}
