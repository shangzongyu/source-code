// Created by cgo - DO NOT EDIT

//line main.go:1
// Copyright © 2017 ChaiShushan <chaishushan{AT}gmail.com>.
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

package main

import _ "unsafe"

func main() {}
