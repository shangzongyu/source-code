// Copyright © 2017 ChaiShushan <chaishushan{AT}gmail.com>.
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

package vector

func Find(vec []int, num int) bool

func SumVec(vec1 []int32, vec2 []int32) [4]int32
