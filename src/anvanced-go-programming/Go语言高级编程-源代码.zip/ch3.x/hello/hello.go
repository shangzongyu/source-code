// Copyright © 2017 ChaiShushan <chaishushan{AT}gmail.com>.
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

package hello

var text = "你好, 世界, 包变量\n"

func PrintHelloWorld()
func PrintHelloWorld_zh()
func PrintHelloWorld_var()
