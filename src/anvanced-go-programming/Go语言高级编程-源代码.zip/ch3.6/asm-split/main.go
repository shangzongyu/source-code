package main

//go:nosplit
func main() {
	printnl()
}

func printnl()
