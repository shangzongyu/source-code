// go run chai2010.cn/gobook/examples/ch1.1/1-hello

package main

import "fmt"

func main() {
	fmt.Println("你好, 世界!")
}
