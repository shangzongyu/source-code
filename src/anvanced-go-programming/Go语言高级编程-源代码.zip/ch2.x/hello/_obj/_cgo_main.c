int main() { return 0; }
void crosscall2(void(*fn)(void*, int, __SIZE_TYPE__), void *a, int c, __SIZE_TYPE__ ctxt) { }
__SIZE_TYPE__ _cgo_wait_runtime_init_done() { return 0; }
void _cgo_release_context(__SIZE_TYPE__ ctxt) { }
char* _cgo_topofstack(void) { return (char*)0; }
void _cgo_allocate(void *a, int c) { }
void _cgo_panic(void *a, int c) { }
void _cgo_reginit(void) { }
#line 1 "cgo-generated-wrappers"
int _cgoexp_16f1900c27a8_helloInt;
int _cgoexp_16f1900c27a8_helloString;
int _cgoexp_16f1900c27a8_helloSlice;
