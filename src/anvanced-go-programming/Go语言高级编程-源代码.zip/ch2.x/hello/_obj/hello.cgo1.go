// Created by cgo - DO NOT EDIT

//line /Users/chai/go/src/github.com/chai2010/advanced-go-programming-book/examples/ch2-xx/hello/hello.go:1
package main

//line /Users/chai/go/src/github.com/chai2010/advanced-go-programming-book/examples/ch2-xx/hello/hello.go:5
func main() {
	helloString("hello")
}

//line /Users/chai/go/src/github.com/chai2010/advanced-go-programming-book/examples/ch2-xx/hello/hello.go:10
func helloInt(s int) {
	println(s)
}

//line /Users/chai/go/src/github.com/chai2010/advanced-go-programming-book/examples/ch2-xx/hello/hello.go:15
func helloString(s string) {
	println(s)
}

//line /Users/chai/go/src/github.com/chai2010/advanced-go-programming-book/examples/ch2-xx/hello/hello.go:20
func helloSlice(s []byte) {
	println(string(s))
}
