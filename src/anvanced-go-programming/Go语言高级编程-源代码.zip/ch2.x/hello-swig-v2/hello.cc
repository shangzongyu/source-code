// Copyright © 2016 ChaiShushan (chaishushan{AT}gmail.com).
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

#include <iostream>

void SayHello() {
	std::cout << "Hello, World!" << std::endl;
}
