// Copyright © 2016 ChaiShushan (chaishushan{AT}gmail.com).
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

// +build ignore

package main

import (
	hello "."
)

func main() {
	hello.SayHello()
}
