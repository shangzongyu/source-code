// Copyright © 2017 ChaiShushan <chaishushan{AT}gmail.com>.
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

#include "say-hello.h"
#include <stdio.h>

int main() {
	SayHello("gopher");
	return 0;
}
