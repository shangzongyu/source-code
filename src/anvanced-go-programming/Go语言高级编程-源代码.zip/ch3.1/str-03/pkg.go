package pkg

var NameData [8]byte

var Name string
