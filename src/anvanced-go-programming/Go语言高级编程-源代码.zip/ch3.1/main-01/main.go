package main

var helloworld = "你好, 世界"

func main()
