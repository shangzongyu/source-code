package pkg

var Name = "gopher"
