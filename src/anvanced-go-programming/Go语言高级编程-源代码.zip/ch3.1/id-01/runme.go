// +build ignore

package main

import pkg "."

func main() {
	println(pkg.Id)
}
