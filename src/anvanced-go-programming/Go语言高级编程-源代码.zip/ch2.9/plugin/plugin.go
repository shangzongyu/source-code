// Copyright © 2017 ChaiShushan <chaishushan{AT}gmail.com>.
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

// +build ignore
// +build go1.10

package main

import "fmt"

func main()

var V int

func F() { fmt.Printf("Hello, number %d\n", V) }
