int number_add_mod(int a, int b, int mod);
