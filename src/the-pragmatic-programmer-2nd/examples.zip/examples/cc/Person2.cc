//START:ex
class Date;

class  Person2 {
private:
  Date *myBirthdate;
public:
  Person2(Date &birthDate);
  // ...
//END:ex
};
