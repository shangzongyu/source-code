//START:ex
#include "date.h"

class  Person1 {
private:
  Date myBirthdate;
public:
  Person1(Date &birthDate);
  // ...
//END:ex
};

