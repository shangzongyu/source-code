#ifndef __DATE_H__ 
#define __DATE_H__ 

class Date {
    public:
        // Creation
        Date();   
        Date(const Date &); 
        const Date &  operator= (const Date &);
        virtual ~Date();  
        
        // Command

        // Query

    private:

};


#endif
